<?php
/**
 * The Account ajax - Login / Register with Ajax
 *
 * @since   1.0.0
 * @package Kalles
 */
?>
    <div class="the4-account-ajax the4-push-menu">
        <?php t4_woo_login_register_form(); ?>
    </div>
