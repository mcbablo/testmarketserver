<?php
/**
 * The template for displaying the footer Megamenu custom post.
 *
 * @since   1.0.0
 * @package Kalles
 */
?>

		<?php wp_footer(); ?>
	</body>
</html>