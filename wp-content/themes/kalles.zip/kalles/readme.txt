Theme Name: Kalles
Theme URI: http://www.the4.co/kalles
Theme Documentation: http://www.the4.co/kalles/document
Theme Support: http://support.the4.net/forums/forum/themes-support/kalles/
