<?php
/**
 * The template for displaying archive pages.
 *
 * @since   1.0.0
 * @package Kalles
 */

get_template_part( 'index' );