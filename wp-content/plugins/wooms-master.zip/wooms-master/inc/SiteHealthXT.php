<?php

namespace WooMS\SiteHealth;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

