<?php

define('ABSPATH', "");

require "TestCase.php";

require_once __DIR__ . '/../../functions.php';

/**
 * Подключение компонентов
 */
require_once __DIR__ . '/../../inc/ProductsWalker.php';
require_once __DIR__ . '/../../inc/ProductsPrices.php';


 // require_once __DIR__ . '/../../inc/LoaderIcon.php';

// require_once __DIR__ . '/../../inc/MenuSettings.php';
// require_once __DIR__ . '/../../inc/MenuTools.php';
// require_once __DIR__ . '/../../inc/ProductsServices.php';
// require_once __DIR__ . '/../../inc/ProductsCategories.php';
// require_once __DIR__ . '/../../inc/ProductsHiding.php';

// require_once __DIR__ . '/../../inc/ProductGallery.php';
// require_once __DIR__ . '/../../inc/ProductImage.php';
// require_once __DIR__ . '/../../inc/SiteHealth.php';
// require_once __DIR__ . '/../../inc/SiteHealthDebugSection.php';
// require_once __DIR__ . '/../../inc/LoggerProductSave.php';
// require_once __DIR__ . '/../../inc/UseCodeAsArticle.php';
