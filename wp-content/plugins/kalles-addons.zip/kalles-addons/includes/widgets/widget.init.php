<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

// require KALLES_ADDONS_WIDGET_PATH . 'recent-posts.php';

// //register_widget( 'Kalles_Widget_Recent_Posts' );
// function kalles_register_widgets() {
//     die();
//     register_widget('Kalles_Widget_Recent_Posts');
// //    register_widget('Kalles_WC_Widget_Product_Categories');
// }
// add_action( 'widgets_init', 'kalles_register_widgets' );


